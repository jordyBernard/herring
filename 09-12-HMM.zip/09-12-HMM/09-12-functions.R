# -------------------------------------------------------------------------
# -------------------------------------------------------------------------
# Main Functions
# -------------------------------------------------------------------------
# -------------------------------------------------------------------------
# -------------------------------------------------------------------------
# Function to clean up transceiver data
clean.transceiver.data <- function(transceiver_data_raw){
  transceiver_data_raw <- as.data.frame(transceiver_data_raw)
  transceiver_data_cleaned <- transceiver_data_raw[,-c(1,2, 6:9, 14:19)]
  names(transceiver_data_cleaned) <- c("Time", "Receiver", "Transmitter", "Region", "Station","Lat","Lon")
  transceiver_data_cleaned$Receiver <- as.factor(transceiver_data_cleaned$Receiver) 
  transceiver_data_cleaned$Transmitter <- as.factor(transceiver_data_cleaned$Transmitter)
  transceiver_data_cleaned$Region<-as.factor(transceiver_data_cleaned$Region)
  transceiver_data_cleaned$Station<- as.factor(transceiver_data_cleaned$Station)
  return(transceiver_data_cleaned)
}

# -------------------------------------------------------------------------
# Function to clean up tagging data
clean.tagging.data <- function(tagging_data_raw){
  tagging_data_raw <- as.data.frame(tagging_data_raw)
  tagging_data_cleaned <- tagging_data_raw[,c(4,2,7,9,16,17)]
  names(tagging_data_cleaned) <- c("Transmitter", "Cohort","TagLife","ReleaseTime","Condition","Sex")
  sex_vec <- tagging_data_cleaned$Sex
  for(i in 1:length(sex_vec)){
    if (sex_vec[i]=="Unk"){
      sex_vec[i]<-"UNK"
    }
  }
  sex_vec <- as.factor(as.character(sex_vec))
  tagging_data_cleaned$Sex <- sex_vec
  tagging_data_cleaned$Cohort <- as.factor(tagging_data_cleaned$Cohort)
  tagging_data_cleaned <- bin.condition(tagging_data_cleaned)
  return(tagging_data_cleaned)
}

# -------------------------------------------------------------------------
# Function to clean up upload data
clean.upload.data <- function(upload_data){
  upload_data <- na.omit(upload_data)
  deploy_date <- rep(NA, nrow(upload_data))
  upload_date <- rep(NA, nrow(upload_data))
  for(i in 1:nrow(upload_data)){
    deploy_date[i] <- substr(upload_data[i,2], start=1, stop=10)
    upload_date[i] <- substr(upload_data[i,3], start=1, stop=10)
  }
  return(data.frame(station=upload_data$STATION, deployDate=as.POSIXct(deploy_date), uploadDate=as.POSIXct(upload_date)))
}

# -------------------------------------------------------------------------
# Function to bin condition into 2 levels ("good" and "poor")
bin.condition <- function(tagging_data_cleaned){
  condition <- rep(NA, nrow(tagging_data_cleaned))
  condition[tagging_data_cleaned$Condition < median(tagging_data_cleaned$Condition)] <- "poor"
  condition[tagging_data_cleaned$Condition >= median(tagging_data_cleaned$Condition)] <-"good"
  tagging_data_cleaned$Condition <- as.factor(condition)
  return(tagging_data_cleaned)
}

# -------------------------------------------------------------------------
# Function to remove isolated (single) detections
filter.single.detections <- function(transceiver_data_cleaned, time="hour"){
  transceiver_data <- transceiver_data_cleaned
  transceiver_data <- na.omit(transceiver_data)
  transceiver_data <- transceiver_data[order(transceiver_data$Time),]
  n<-nrow(transceiver_data)
  keepers <- rep(F, n)
  if (time=="hour"){
    spw <- 1800
  } else if (time=="day"){
    spw <- 43200
  } else if (time=="week"){
    spw <-302400
  }
  names(transceiver_data) <- c("Time", "Receiver", "Transmitter", "Region", "Station","Lat","Lon")
  for (i in 1:(n-1)){
    second_detect <- F
    j<-1
    while (second_detect==F & transceiver_data$Time[i+j]<=(transceiver_data$Time[i]+spw)){
      if (transceiver_data$Transmitter[i]==transceiver_data$Transmitter[i+j] & transceiver_data$Region[i]==transceiver_data$Region[i+j]){
        second_detect <- T
        break
      }
      j<-j+1
      if(i+j > n){
        break
      }
    }
    k<-1
    if (i-k>0 & second_detect==F){
      while (second_detect==F & transceiver_data$Time[i-k]>=(transceiver_data$Time[i]-spw)){
        if (transceiver_data$Transmitter[i]==transceiver_data$Transmitter[i-k] & transceiver_data$Region[i]==transceiver_data$Region[i-k]){
          second_detect <-T
          break
        }
        k<-k+1
        if (i-k < 1){
          break
        }
      }
    }
    keepers[i] <- second_detect
    if((i%%5000) == 0){
      print(round(i/n, 2))
    }
  }
  m <- sum(keepers)-n
  print(paste(m, "fish were detected only one time and moved from the returned data.frame", sep=" "))
  return(transceiver_data[keepers,])
}

# -------------------------------------------------------------------------
# Isolate receiver coordinate data
isolate.receiver.data <- function(transceiver_data_filtered){
  transceiver_data <- transceiver_data_filtered 
  library(dplyr)
  receiver_data <- data.frame(Receiver=transceiver_data$Receiver, Station=transceiver_data$Station, Region=transceiver_data$Region, Lat=transceiver_data$Lat, Lon=transceiver_data$Lon) %>% distinct()
  return(receiver_data)
}

# -------------------------------------------------------------------------
# Adds side information to the main df, removes duplicates so that there is a maximum of one detection for each time, and removes information that is no longer needed such as receiver info
add.side <- function(transceiver_data_filtered, receiver_data){
  library(dplyr)
  n<- nrow(transceiver_data_filtered)
  side <- rep(NA, n)
  for (i in 1:n){
    detection <- transceiver_data_filtered[i,]
    side[i] <- receiver_data$Side[receiver_data$Receiver==detection$Receiver & receiver_data$Station==detection$Station][1]
    if(i%%5000 == 0){
      print(round(i/n, 2))
    }
  }
  transceiver_data_side <- cbind(transceiver_data_filtered, side)
  names(transceiver_data_side)[8] <- "Side"
  transceiver_data_side <- transceiver_data_side[, -c(2,5,6,7)]
  transceiver_data_side$Side <- as.character(transceiver_data_side$Side)
  transceiver_data_side <- distinct(transceiver_data_side)
  n <- nrow(transceiver_data_side)
  side <- rep(NA, n)
  for (i in 1:n){
    detections <- transceiver_data_side[transceiver_data_side$Time == transceiver_data_side$Time[i] & transceiver_data_side$Transmitter == transceiver_data_side$Transmitter[i], ]
    detection_sides <- detections$Side
    if (length(unique(detection_sides)) == 1){
      side[i] <- detection_sides[1]
    }else{
      side[i] <- "both"
    }
    if(i%%5000 == 0){
      print(round(i/n, 2))
    }
  }
  transceiver_data_side$Side <- side
  transceiver_data_side$Side <- as.factor(transceiver_data_side$Side)
  return(transceiver_data_side)
}

# -------------------------------------------------------------------------
# Function to determine the observed data associated with each detection following the encoding below:
# 1 -- No detection
# 2 -- Gravina, RedGravina, or Hawkins detection
# 3 -- NoMontague or Mobile detection
# 4 -- Hinchinbrook detection
# 5 -- Montague detection
# 6 -- Latouche, Elrington, Prince of Wales or Bainbridge detection
add.observation.encoding <- function(transceiver_data_side){
  n <- nrow(transceiver_data_side)
  obs.enc <- rep(NA, n)
  for (i in 1:n){
    detection <- transceiver_data_side[i,]
    if (detection$Region == "Gravina" || detection$Region == "RedGravina" || detection$Region == "Hawkins"){
      obs.enc[i] <- 2
    }else if (detection$Region == "NoMontague" || detection$Region == "Mobile"){
      obs.enc[i] <- 3
    }else if (detection$Region == "Hinchinbrook"){
      obs.enc[i] <- 4
    }else if (detection$Region == "Montague"){
      obs.enc[i] <- 5
    }else if (detection$Region == "LaTouche" || detection$Region == "Elrington" || detection$Region == "Prince of Wales" || detection$Region == "Bainbridge"){
      obs.enc[i] <- 6
    }
    if(i%%5000 == 0){
      print(round(i/n, 2))
    }
  }
  obs_data <- cbind(transceiver_data_side[,c(1,2,4)], obs.enc)
  names(obs_data)[4] <- "Obs" 
  return(obs_data)
}

# -------------------------------------------------------------------------
# Funtion to return the time when the receiver data was uploaded last
get.end.time <- function(upload_data_cleaned){
  return(max(upload_data_cleaned$uploadDate))
}

# -------------------------------------------------------------------------
# Function to return the time the first fish was released
get.start.time <- function(tagging_data_cleaned){
  return(min(tagging_data_cleaned$ReleaseTime))
}

# -------------------------------------------------------------------------
# Returns the number of days a time is after the start time
get.day <- function(time, start_time){
  day <- rep(NA, length(time))
  for (i in 1:length(time)){
    day[i] <- as.numeric(ceiling(difftime(time[i], start_time, units="days")))
    if (day[i] == 0){
      day[i] <- 1
    }
  }
  return(day)
}

# -------------------------------------------------------------------------
# Compute the detection or "capture" history for each individual
get.detecton.history.list <- function(transceiver_data_encoded, start_time, end_time){
  num_days <- get.day(end_time, start_time)
  days <- get.day(transceiver_data_encoded$Time, start_time)
  detection_histories <- list()
  for (j in 1:length(levels(transceiver_data_encoded$Transmitter))){
    fish <- levels(transceiver_data_encoded$Transmitter)[j]
    obs <- rep(NA, num_days)
    direction <- rep(NA, num_days)
    for (day in 1:num_days){
      detections <- transceiver_data_encoded[transceiver_data_encoded$Transmitter==fish & days == day, ]
      if (nrow(detections)==0){
        obs[day] <- 1
      } else if (length(unique(detections$Obs))==1){
        obs[day] <- detections$Obs[1]
        if (length(unique(detections$Side)) != 1){
          first_side <- detections$Side[1]
          last_side <- detections$Side[nrow(detections)]
          if (first_side == "in" & last_side == "out"){
            direction[day] <- "io"
          } else if (first_side=="out" & last_side == "in"){
            direction[day] <- "oi"
          }
        }
      } else{
        obs[day] <- detections$Obs[1]
        print(paste("Fish", levels(transceiver_data_encoded$Transmitter)[j], "detected in different regions on day", day, sep=" "))
        print("using the first region where the fish was detected")
      }
    }
    detection_histories[[j]] <- data.frame(obs, direction)
    if(j%%10 == 0){
      print(round(j/length(levels(transceiver_data_encoded$Transmitter)), 2))
    }
  }
  names(detection_histories) <- levels(transceiver_data_encoded$Transmitter)
  return(detection_histories)
}

# -------------------------------------------------------------------------
# Function to extract detection history data for Jags model
get.y <- function(detection_history_list){
  y <- matrix(NA, nrow=length(detection_history_list), ncol=nrow(detection_history_list[[1]]))
  row.names(y) <- names(detection_history_list)
  for (i in 1:length(detection_history_list)){
    y[i,] <- detection_history_list[[i]][,1]
  }
  row.names(y) <- names(detection_history_list)
  return(y)
}

# -------------------------------------------------------------------------
# Function to tell us how many days are in each season
get.days.per.season <- function(date_vector){
  new_date_vector <- as.POSIXct(date_vector)
  days <- rep(NA, (length(date_vector)-1))
  for (i in 1:(length(date_vector)-1)){
    days[i] <- as.numeric(round(difftime(date_vector[[i+1]], date_vector[[i]], units="days")))
  }
  return(days)
}

# -------------------------------------------------------------------------
# Function to extract io/oi counts at the entrance arrays
# Will need to add a bit here to encode tag-burden and weight, but we'll worry about that later
get.side.counts <- function(days_per_season, detection_history_list, by, tagging_data_cleaned, entrance){
  if (by =="sex"){
    index <- 6
  }else if (by=="condition"){
    index <- 5
  }
  io_mat <- matrix(0, nrow=length(days_per_season), ncol=length(levels(tagging_data_cleaned[,index])))
  oi_mat <- matrix(0, nrow=length(days_per_season), ncol=length(levels(tagging_data_cleaned[,index])))
  for(k in 1:length(levels(tagging_data_cleaned[,index]))){
    fish_ids <- tagging_data_cleaned$Transmitter[tagging_data_cleaned[,index]==levels(tagging_data_cleaned[,index])[k]]
    for (i in 1:length(detection_history_list)){
      if (is.element(names(detection_history_list)[i], tagging_data_cleaned$Transmitter)){
        if (is.element(names(detection_history_list)[i], fish_ids)){
          lb <- 1
          ub <- days_per_season[1]
          for (j in 1:length(days_per_season)){
            io_mat[j,k] <- io_mat[j,k] + sum(na.omit(detection_history_list[[i]][lb:ub,2]=="io" & detection_history_list[[i]][lb:ub,1]==entrance))
            oi_mat[j,k] <- oi_mat[j,k] + sum(na.omit(detection_history_list[[i]][lb:ub,2]=="oi" & detection_history_list[[i]][lb:ub,1]==entrance))
            lb <- lb + days_per_season[j]
            if (j != length(days_per_season)){
              ub <- ub + days_per_season[j+1]
            }
          }
        }
      }
    }
  }
  side_counts <- list("io"=io_mat,"oi"=oi_mat)
  for(i in 1:2){
    side_counts[[i]]<-side_counts[[i]]+1
  }
  return(side_counts)
}  

# Function to calculate the proportion of fish that stay vs leave between consecutive time periods at each of the array locations
get.prop.stay <- function(y, t_0, tl){
  sh <- 0
  gh <- 0
  sm <- 0
  gm <- 0
  ss <- 0
  gs <- 0
  for (i in 1:nrow(y)){
    for (j in t_0[i]:(min(t_0[i]+tl[i], ncol(y))-1)){
      if (y[i,j]==4 & y[i,j+1]==4){
        sh <- sh + 1
      }else if (y[i,j]==4 & y[i,j+1]!=4){
        gh <- gh + 1
      }else if (y[i,j]==5 & y[i,j+1]==5){
        sm <- sm + 1
      }else if (y[i,j]==5 & y[i,j+1]!=5){
        gm <- gm + 1
      }else if (y[i,j]==6 & y[i,j+1]==6){
        ss <- ss + 1
      }else if (y[i,j]==6 & y[i,j+1]!=6){
        gs <- gs +1
      }
    }
  }
  prop_stay <- c(sh/(sh+gh), sm/(sm+gm), ss/(ss+gs))
  names(prop_stay) <- c("h", "m", "s")
  return(prop_stay)
}

# -------------------------------------------------------------------------
# Function to estimate stay counts
get.est.stay <- function(side_counts, prop_stay){
  num_go <- side_counts$io+side_counts$oi
  r <- prop_stay/(1-prop_stay)
  num_stay <- floor(r*num_go)
  return(num_stay)
}

# -------------------------------------------------------------------------
# Function to prepare entrance array inits for Jags model
prep.entrance.inits <- function(side_counts, prop_stay){
  stay_counts <- get.est.stay(side_counts, prop_stay)
  ent_inits <- array(NA, dim=c(3,nrow(side_counts$io),ncol(side_counts$io)))
  ent_inits[1,,] <- side_counts$oi
  ent_inits[2,,] <- stay_counts
  ent_inits[3,,] <- side_counts$io
  return(ent_inits)
}

# -------------------------------------------------------------------------
# Function to figure out which fish in the tagging data aren't included in the detection_history_list
find.missing.fish <- function(detection_history_list, tagging_data_cleaned){
  missing_fish <- rep(NA, length(tagging_data_cleaned$Transmitter)-length(names(detection_history_list)))
  j<-1
  for(i in 1:length(tagging_data_cleaned$Transmitter)){
    fish <- tagging_data_cleaned$Transmitter[i]
    if (!is.element(fish, names(detection_history_list))){
      missing_fish[j] <- fish
      j<-j+1
    }
  }
  return(missing_fish)
}

# -------------------------------------------------------------------------
# function to add the detection history of the fish that was never heard from again
add.fish.to.y <- function(id, y){
  dh <- rep(1, ncol(y))
  new_y <- rbind(y, dh)
  rownames(new_y)[nrow(new_y)]<-id
  return(new_y)
}

# -------------------------------------------------------------------------
# Functions to extract sex information for Jags model. 1 -- Female; 2 -- Male; 3 -- Unknown
get.sex <- function(y, tagging_data_cleaned){
  sex <- rep(NA, nrow(y))
  for (i in 1:length(rownames(y))){
    fish <- rownames(y)[i]
    sex[i] <- as.character(tagging_data_cleaned$Sex[tagging_data_cleaned$Transmitter==fish])
  }
  return(as.factor(sex))
}


# -------------------------------------------------------------------------
# Function to extract cohort information for Jags model. Numbers coorespond directly with cohort
get.cohort <- function(y, tagging_data_cleaned){
  cohort <- rep(NA, nrow(y))
  for (i in 1:length(rownames(y))){
    fish <- rownames(y)[i]
    cohort[i] <- tagging_data_cleaned$Cohort[tagging_data_cleaned$Transmitter==fish]
  }
  return(as.factor(cohort))
}

# -------------------------------------------------------------------------
# Function to extract condition information for Jags model. 1 -- good; 2 -- poor
get.condition <- function(y, tagging_data_cleaned){
  condition <- rep(NA, nrow(y))
  for (i in 1:length(rownames(y))){
    fish <- rownames(y)[i]
    condition[i] <- tagging_data_cleaned$Condition[tagging_data_cleaned$Transmitter==fish]
  }
  return(as.factor(condition))
}

# -------------------------------------------------------------------------
# Function returns the day on which the fish was tagged
get.tagging.time <- function(y, tagging_data_cleaned){
  tt <- rep(NA, nrow(tagging_data_cleaned)) 
  first_tt <- min(tagging_data_cleaned$ReleaseTime)
  for(i in 1:nrow(tagging_data_cleaned)){
    tt[i] <- as.numeric(round(difftime(tagging_data_cleaned$ReleaseTime[i], first_tt, units="days")))
  }
  names(tt)<-tagging_data_cleaned$Transmitter
  new_tt <- rep(NA, length(tt))
  for (i in 1:length(rownames(y))){
    fish <- rownames(y)[i]
    new_tt[i] <- tt[names(tt)==fish]
  }
  names(new_tt) <- row.names(y)
  return(new_tt)
}

# -------------------------------------------------------------------------
# Function to return a vector of tag life
get.tag.life <- function(y, tagging_data_cleaned){
  tl <- tagging_data_cleaned$TagLife
  # Tags with unknown Taglife are active regardless of taglife at time of analysis, I'm giving them an arbitrary taglife of 246 days
  unk_tags <- tagging_data_cleaned$Transmitter[tl=="UNK"]
  tagging_data_cleaned[is.element(tagging_data_cleaned$Transmitter,unk_tags),]
  for (i in 1:length(tl)){
    if (tl[i]=="UNK"){
      tl[i]<-"246"
    }
  }
  tl <- as.numeric(tl)
  names(tl)<-tagging_data_cleaned$Transmitter
  new_tl <- rep(NA, length(tl))
  for (i in 1:length(rownames(y))){
    fish <- rownames(y)[i]
    new_tl[i] <- tl[names(tl)==fish]
  }
  names(new_tl) <- row.names(y)
  return(new_tl)
}

# -------------------------------------------------------------------------
# function to find to season that cooresponding to each day
get.season <- function(dps){
  seasons <- c()
  for (i in 1:length(dps)){
    seasons <- c(seasons, rep(i,dps[i])) 
  }
  return(seasons)
}

# -------------------------------------------------------------------------
# Functions to compress data so that stuff can run in Jags
compress.y <- function(y, bin_by){
  num_col <- floor(ncol(y)/bin_by)
  new_y <- matrix(1, nrow=nrow(y), ncol=num_col)
  for (r in 1:nrow(new_y)){
    for (i in 1:num_col){
      start_index <- (i-1)*bin_by
      for(j in 1:bin_by){
        dat <- y[r,start_index+j]
        if (dat == 2){
          new_y[r,i] <- 2
        }else if (dat == 3){
          new_y[r,i] <- 3
        }else if (dat == 4){
          new_y[r,i] <- 4
        }else if (dat == 5){
          new_y[r,i] <- 5
        }else if (dat == 6){
          new_y[r,i] <- 6
        }
      }
    }
  }
  row.names(new_y) <- row.names(y)
  return(new_y)
}

# -------------------------------------------------------------------------
# Function to check for inconsistent detections
get.incon.detect <- function(y){
  num.incon <- 0
  for (i in 1:nrow(y)){
    for(j in 1:(ncol(y)-1)){
      if ((y[i,j] == 2 || y[i,j] == 3 || y[i,j] == 4 || y[i,j] == 5 || y[i,j] == 6) &
          (y[i,j+1] == 2 || y[i,j+1] == 3 || y[i,j+1] == 4 || y[i,j+1] == 5 || y[i,j+1] == 6) &
          (y[i,j]!=y[i,j+1])){
        num.incon <- num.incon + 1
      }
    }
  }
  incon <- rep(NA, num.incon)
  k <- 1
  for (i in 1:nrow(y)){
    for(j in 1:(ncol(y)-1)){
      if ((y[i,j] == 2 || y[i,j] == 3 || y[i,j] == 4 || y[i,j] == 5 || y[i,j] == 6) &
          (y[i,j+1] == 2 || y[i,j+1] == 3 || y[i,j+1] == 4 || y[i,j+1] == 5 || y[i,j+1] == 6) &
          (y[i,j]!=y[i,j+1])){
        incon[k] <- i
        k <- k+1
      }
    }
  }
  return(incon)
}

# -------------------------------------------------------------------------
# Function to remove inconsistent detections
remove.incon.detect <- function(y){
  incon_detect <- get.incon.detect(y)
  for(i in incon_detect){
    for (j in 1:(ncol(y)-1)){
      if (is.element(y[i,j], c(2,3,4,5,6)) & is.element(y[i,j+1],c(2,3,4,5,6)) & y[i,j]!=y[i,j+1]){
        y[i,j+1]<-1
      }
    }
  }
  return(y)
}

adjust.t_0 <- function(t_0, bin_by){
  new_t_0 <- ceiling(t_0/bin_by)
  for(i in 1:length(new_t_0)){
    if (new_t_0[i]==0){
      new_t_0[i] <- 1
    }
  }
  return(new_t_0)
}

adjust.dps <- function(dps, bin_by){
  tps <- rep(NA, length(dps))
  for(i in 1:length(dps)){
    cum_days <- sum(dps[1:i])
    tps[i] <- floor(cum_days/bin_by)
  }
  for(i in 2:length(dps)){
    tps[i] <- tps[i]-sum(tps[1:i-1])
  }
  return(tps)
}

adjust.tl <- function(tl, bin_by){
  new_tl <- floor(tl/bin_by)
  return(new_tl)
}

# -------------------------------------------------------------------------
# Function to initialize hidden state vector for Jags model
get.hidden.inits <- function(y, t_0, tl){
  z <- matrix(NA, nrow=nrow(y), ncol=ncol(y))
  for (i in 1:nrow(z)){
    last_det <- "p"
    state <- "pws"
    for (j in 1:(ncol(z)-1)){
      if (is.element(y[i,j], c(2,3))){
        z[i,j] <- y[i,j]
        last_det <- "p"
      }else if (is.element(y[i,j], c(4,5,6))){
        z[i,j] <- y[i,j]+1
        last_det <- "e"
        if (state == "pws" & y[i,j]!=y[i,j+1]){
          state <- "goa"
        }else if (state == "goa" & y[i,j]!=y[i,j+1]){
          state <- "pws"
        }
      }else if (y[i,j]==1){
        if (last_det == "p"){
          z[i,j] <- 4
        }else if (last_det =="e"){
          if (state=="pws"){
            z[i,j] <- 4
          }else if (state=="goa")
            z[i,j] <- 8
        }
      }
    }
    j <- ncol(y)
    if (is.element(y[i,j], c(2,3))){
      z[i,j] <- y[i,j]
    } else if (is.element(y[i,j], c(4,5,6))){
      z[i,j] <- y[i,j]+1
    } else{
      z[i,j] <- z[i, j-1]
    }
  }
  for(i in 1:nrow(z)){
    for(j in 1:ncol(z)){
      if (j < t_0[i]){
        z[i,j] <- NA
      }else if (j > t_0[i]+tl[i]-1){
        z[i,j] <- NA
      }
    }
  }
  return(z)
}

# -------------------------------------------------------------------------
# Function that returns list of relevant data used in Jags model
gather.data <- function(y, x_data, t_0, side_counts, prop_stay, dps, tl){
  side_counts_h <- side_counts[[1]]
  side_counts_m <- side_counts[[2]]
  side_counts_s <- side_counts[[3]]
  prop_stay_h <- prop_stay[1]
  prop_stay_m <- prop_stay[2]
  prop_stay_s <- prop_stay[3]
  data <- list(y_data = y, 
               x_data = x_data,
               t_0 = t_0,
               M = nrow(y),
               n_seasons = length(dps),
               n_x_vals = length(levels(x_data)),
               N = sum(dps),
               tl=tl,
               season=get.season(dps),
               h_data = prep.entrance.inits(side_counts_h, prop_stay_h),
               m_data = prep.entrance.inits(side_counts_m, prop_stay_m),
               s_data = prep.entrance.inits(side_counts_s, prop_stay_s))
  return(data)
}

# -------------------------------------------------------------------------
# Function to retreive inits for the Jags model
inits <- function(y, dps, x_data, t_0, tl){
  library(rBeta2009)
  n_seasons <- length(dps)
  n_x_vals <- length(levels(x_data))
  S4 <- matrix(NA, n_seasons, n_x_vals)
  S8 <- matrix(NA, n_seasons, n_x_vals)
  psi2 <- array(NA, dim=c(2,n_seasons, n_x_vals))
  psi3 <- array(NA, dim=c(2,n_seasons, n_x_vals))
  psi4 <- array(NA, dim=c(6,n_seasons, n_x_vals)) 
  psi5 <- array(NA, dim=c(3,n_seasons, n_x_vals))
  psi6 <- array(NA, dim=c(3,n_seasons, n_x_vals))
  psi7 <- array(NA, dim=c(3,n_seasons, n_x_vals))
  psi8 <- array(NA, dim=c(5,n_seasons, n_x_vals))
  for (s in 1:n_seasons){
    for (x in 1:n_x_vals){
      # S4[s,x] <- rbeta(1,1,1)
      # S8[s,x] <- rbeta(1,1,1)
      # psi2[1,s,x] <- rbeta(1,1,1)
      # psi2[2,s,x] <- 1-psi2[1,s,x]
      # psi3[1,s,x] <- rbeta(1,1,1)
      # psi3[2,s,x] <- 1-psi3[1,s,x]
      # psi4[,s,x] <- rdirichlet(1,c(2,2,2,2,2,2))
      # psi5[,s,x] <- rdirichlet(1,c(2,2,2))
      # psi6[,s,x] <- rdirichlet(1,c(2,2,2))
      # psi7[,s,x] <- rdirichlet(1,c(2,2,2))
      # psi8[,s,x] <- rdirichlet(1,c(2,2,2,2,2))
      S4[s,x] <- .999
      S8[s,x] <- .999
      psi2[1,s,x] <- .5
      psi2[2,s,x] <- 1-psi2[1,s,x]
      psi3[1,s,x] <- .5
      psi3[2,s,x] <- 1-psi3[1,s,x]
      psi4[,s,x] <- rep(1/6,6)
      psi5[,s,x] <- rep(1/3,3)
      psi6[,s,x] <- rep(1/3,3)
      psi7[,s,x] <- rep(1/3,3)
      psi8[,s,x] <- rep(1/5,5)
    }
  }
  z <- get.hidden.inits(y,t_0,tl)
  return(list(S4=S4,
              S8=S8,
              psi2=psi2,
              psi3=psi3,
              psi4=psi4,
              psi5=psi5,
              psi6=psi6,
              psi7=psi7,
              psi8=psi8,
              z=z
  ))
}

# -------------------------------------------------------------------------
# Function to run Jags model
# We should parallelize this at a minimum
# Start by checking outh the function jags.parallel in the R2Jags package
model <- function(file_path, y, x_data, t_0, side_counts, prop_stay, dps, tl){
  library(rjags)
  model = jags.model(file_path,
                     data=gather.data(y, x_data, t_0, side_counts, prop_stay, dps, tl),
                     inits=inits(y, dps, x_data, t_0, tl),
                     n.chains = 2,
                     n.adapt = 10000)
}


# -------------------------------------------------------------------------
# -------------------------------------------------------------------------
# Functions used in diagnostics
# -------------------------------------------------------------------------
# -------------------------------------------------------------------------
# -------------------------------------------------------------------------
# Function that returns passage times at a given receiver, station, or region and a histogram of the return times. Additional arguments allow for the specification of the calendar year, transmitter id, and histogram breaks points
plot.detection.times <- function(transceiver_data_filtered, 
                                 year="unspecified", 
                                 receiver="unspecified", 
                                 station="unspecified", 
                                 region="unspecified", 
                                 transmitter="unspecified", 
                                 breaks="days"){
  
  plot_data <- transceiver_data_filtered
  if (year!="unspecified"){
    plot_data <- plot_data[get.year(plot_data$Time)==year, ]
  }
  if (receiver!="unspecified"){
    plot_data <- plot_data[plot_data$Receiver==receiver, ]
  }
  if (station!="unspecified"){
    plot_data <- plot_data[plot_data$Station==station, ]
  }
  if(region!="unspecified"){
    plot_data <- plot_data[plot_data$Region==region, ]
  }
  if(transmitter!="unspecified"){
    plot_data <- plot_data[plot_data$Transmitter==transmitter, ]
  }
  if (nrow(plot_data) == 0){
    print("there were no detections")
  }else{
    detect_times <- plot_data$Time
    hist(detect_times, breaks)
    return(detect_times)
  }
}

# -------------------------------------------------------------------------
# Function to construct contingency table of the fish detected in a region by sex/condition
# May want to modify this so that there is just a "good" and "poor" condition
get.contingency.table <- function(transceiver_data_filtered, tagging_data_cleaned, region="Gravina", year=2017, sex=T, condition=F){
  detections <- transceiver_data_filtered[(transceiver_data_filtered$Region==region & get.year(transceiver_data_filtered$Time)==year), ]
  fish_detected <- levels(detections$Transmitter)
  if (sex == T & condition == F){
    n_male <- 0
    n_female <- 0
    n_unknown <- 0
    for (fish in fish_detected){
      fish_sex <- tagging_data_cleaned$Sex[tagging_data_cleaned$Transmitter == fish]
      if (length(fish_sex != 0)){
        if (fish_sex == "M"){
          n_male <- n_male + 1
        } else if (fish_sex =="F"){
          n_female <- n_female <- n_female + 1
        } else if (fish_sex == "UNK"){
          n_unknown <- n_unknown + 1
        }
      }
    }
    cont_table <- c(n_male, n_female, n_unknown)
    names(cont_table) <- c("Male", "Female", "Unknown")
    return(cont_table)
  }else if(sex == F & condition==T){
    tagging_data_cleaned <- tagging_data_cleaned[order(tagging_data_cleaned$Condition),]
    l_break <- tagging_data_cleaned$Condition[floor(nrow(tagging_data_cleaned)/3)]
    u_break <- tagging_data_cleaned$Condition[nrow(tagging_data_cleaned)-ceiling(nrow(tagging_data_cleaned)/3)]
    n_bad <- 0
    n_ok <- 0
    n_good <- 0
    for (fish in fish_detected){
      fish_condition <- tagging_data_cleaned$Condition[tagging_data_cleaned$Transmitter == fish]
      if (length(fish_condition != 0)){
        if (fish_condition <= l_break){
          n_bad <- n_bad + 1 
        }else if (fish_condition > l_break & fish_condition < u_break){
          n_ok <- n_ok + 1
        }else if (fish_condition >= u_break){
          n_good <- n_good + 1
        }
      }
    }
    cont_table <- c(n_bad, n_ok, n_good)
    names(cont_table) <- c("Bad", "OK", "Good")
    return(cont_table)
  }else if (sex == T & condition == T){
    tagging_data_cleaned <- tagging_data_cleaned[order(tagging_data_cleaned$Condition),]
    l_break <- tagging_data_cleaned$Condition[floor(nrow(tagging_data_cleaned)/3)]
    u_break <- tagging_data_cleaned$Condition[nrow(tagging_data_cleaned)-ceiling(nrow(tagging_data_cleaned)/3)]
    n_male_bad <- 0
    n_male_ok <- 0
    n_male_good <- 0
    n_female_bad <- 0
    n_female_ok <- 0
    n_female_good <- 0
    n_unknown_bad <- 0
    n_unknown_ok <- 0
    n_unknown_good <- 0
    for (fish in fish_detected){
      fish_sex <- tagging_data_cleaned$Sex[tagging_data_cleaned$Transmitter == fish]
      fish_condition <- tagging_data_cleaned$Condition[tagging_data_cleaned$Transmitter == fish]
      if (length(fish_sex != 0)){
        if (fish_condition <= l_break){
          if (fish_sex == "M"){
            n_male_bad <- n_male_bad + 1
          }else if (fish_sex == "F"){
            n_female_bad <- n_female_bad + 1
          }else if (fish_sex == "UNK"){
            n_unknown_bad <- n_unknown_bad + 1
          }
        }else if (fish_condition > l_break & fish_condition < u_break){
          if (fish_sex == "M"){
            n_male_ok <- n_male_ok + 1
          }else if (fish_sex == "F"){
            n_female_ok <- n_female_ok + 1
          }else if (fish_sex == "UNK"){
            n_unknown_ok <- n_unknown_ok + 1
          }
        }else if (fish_condition >= u_break){
          if (fish_sex == "M"){
            n_male_good <- n_male_good + 1
          }else if (fish_sex == "F"){
            n_female_good <- n_female_good + 1
          }else if (fish_sex == "UNK"){
            n_unknown_good <- n_unknown_good + 1
          }
        }
      }
    }
  }
  cont_table <- cbind(c(n_male_bad, n_male_ok, n_male_good), c(n_female_bad, n_female_ok, n_female_good), c(n_unknown_bad, n_unknown_ok, n_unknown_good))
  row.names(cont_table) <- c("Bad", "OK", "Good")
  colnames(cont_table) <- c("Male", "Female", "Unknown")
  return(cont_table)
}

# -------------------------------------------------------------------------
# To determine the percentage of double detections by region
num.double.detections <- function(transceiver_data_side){
  entrances <- c("Bainbridge", "Elrington", "Hinchinbrook", "LaTouche", "Mobile", "Montague", "Prince of Wales")
  double_detections <- rep(0, length(entrances))
  total_detections <- rep(0, length(entrances))
  names(double_detections) <- entrances
  names(total_detections) <- entrances
  for(i in 1:length(entrances)){
    array <- entrances[i]
    detections <- transceiver_data_side[transceiver_data_side$Region==array,]
    double_detections[i]<-sum(detections$Side=="both")
    total_detections[i]<- nrow(detections)
  }
  return(list(both=double_detections, total=total_detections, percentage=double_detections/total_detections))
}

# -------------------------------------------------------------------------
# A few functions to extract the year, month, and day from a POSIXct date
get.year <- function(POSIXt_time){
  return(as.numeric(format(POSIXt_time, format="%Y")))
}
get.month <- function(POSIXt_time){
  return(as.numeric(format(POSIXt_time, format="%m")))
}
get.day <- function(POSIXt_time){
  return(as.numeric(format(POSIXt_time, format="%d")))
}

# -------------------------------------------------------------------------
# A functions to return the region where a receiver or station is located
get.region <- function(data, station="unspecified", receiver="unspecified"){
  if (station != "unspecified"){
    return(data$Region[data$Station==station][1])
  }else if (receiver != unspecified){
    return(data$Region[data$Receiver==receiver][1])
  }
}

# -------------------------------------------------------------------------
# Function to return the number of detections of a given fish. Additional argument is added to allow for year specification
get.num.detect <- function(data, transmitter, year="unspecified"){
  if (year =="unspecified"){
    return(sum(data$Transmitter==transmitter))
  }else{
    return(sum(data$Transmitter==transmitter) & data$Year==year)
  }
}

# -------------------------------------------------------------------------
# Function returning a data.frame of times and stations where a given fish was located
get.detection.stations <- function(transmitter){
  return(data.frame(Time = data$Time[data$Transmitter==transmitter], Station = data$Station[data$Transmitter==transmitter]))
}

# -------------------------------------------------------------------------
# Function returning a data.frame of times and regions where a given fish was located
get.detection.regions <- function(transmitter){
  return(data.frame(Time = data$Time[data$Transmitter==transmitter], Region = data$Region[data$Transmitter==transmitter]))
}

# -------------------------------------------------------------------------
# Function to find the number of times that we get a 2-3 sequence in the detection histories
num.23 <- function(y){
  count <- 0
  indexes <- rep(NA, 56)
  for (i in 1:nrow(y)){
    for (j in 1:(ncol(y)-1)){
      if (y[i,j]==2 & y[i,j+1]==3){
        count <- count+1
        indexes[count] <- i
      }
    }
  }
  return(indexes)
}


# -------------------------------------------------------------------------
# Function to find the numeber of times that we get a 3-2 sequence in the detection histories
num.32 <- function(y){
  count <- 0
  indexes <- rep(NA, 56)
  for (i in 1:nrow(y)){
    for (j in 1:(ncol(y)-1)){
      if (y[i,j]==3 & y[i,j+1]==2){
        count <- count+1
        indexes[count] <- j
      }
    }
  }
  return(indexes)
}


# -------------------------------------------------------------------------
# To make sure we have good initial values for z
num.82 <- function(y, t_0, tl){
  z <- get.hidden.inits(y, t_0, tl)
  count <- 0
  for (i in 1:nrow(z)){
    for (j in 1:(ncol(z)-1)){
      if (!is.na(z[i,j]) & !is.na(z[i,j+1])){
        if (z[i,j] == 8 & z[i,j+1] == 2){
          count <- count+1
        }
      }
    }
  }
  return(count)
}

num.83 <- function(y, t_0, tl){
  z <- get.hidden.inits(y, t_0, tl)
  count <- 0
  for (i in 1:nrow(z)){
    for (j in 1:(ncol(z)-1)){
      if (!is.na(z[i,j]) & !is.na(z[i,j+1])){
        if (z[i,j] == 8 & z[i,j+1] == 3){
          count <- count+1
        }
      }
    }
  }
  return(count)
}


