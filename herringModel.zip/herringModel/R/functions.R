#############################################################################################################################################
# Main Functions
################
# hypergeometric test 

# -------------------------------------------------------------------------
# Function to clean up transceiver data
# Looks good
clean.transceiver.data <- function(transceiver_data_raw){
  transceiver_data_raw <- as.data.frame(transceiver_data_raw)
  transceiver_data_cleaned <- transceiver_data_raw[,-c(1,2, 6:9, 14:19)]
  names(transceiver_data_cleaned) <- c("Time", "Receiver", "Transmitter", "Region", "Station","Lat","Lon")
  transceiver_data_cleaned$Receiver <- as.factor(transceiver_data_cleaned$Receiver) 
  transceiver_data_cleaned$Transmitter <- as.factor(transceiver_data_cleaned$Transmitter)
  transceiver_data_cleaned$Region<-as.factor(transceiver_data_cleaned$Region)
  transceiver_data_cleaned$Station<- as.factor(transceiver_data_cleaned$Station)
  return(transceiver_data_cleaned)
}

# -------------------------------------------------------------------------
# Function to clean up tagging data
# Looks good
clean.tagging.data <- function(tagging_data_raw){
  tagging_data_raw <- as.data.frame(tagging_data_raw)
  tagging_data_cleaned <- tagging_data_raw[,c(3,1,6,10,16,17)]
  names(tagging_data_cleaned) <- c("Transmitter", "Cohort","TagLife","ReleaseTime","Condition","Sex")
  tagging_data_cleaned$Sex <- as.factor(tagging_data_cleaned$Sex)
  tagging_data_cleaned$Cohort <- as.factor(tagging_data_cleaned$Cohort)
  return(tagging_data_cleaned)
}

# -------------------------------------------------------------------------
# Function to bin Condition into 2 levels ("good" and "poor")
bin.condition <- function(tagging_data_cleaned){
  condition <- rep(NA, nrow(tagging_data_cleaned))
  condition[tagging_data_cleaned$Condition < median(tagging_data_cleaned$Condition)] <- "poor"
  condition[tagging_data_cleaned$Condition >= median(tagging_data_cleaned$Condition)] <-"good"
  print(condition)
  tagging_data_cleaned$Condition <- condition
  return(tagging_data_cleaned)
}

# -------------------------------------------------------------------------
# Function to remove isolated (single) detections
# Looks good
filter.single.detections <- function(transceiver_data_cleaned, time="hour"){
  transceiver_data <- transceiver_data_cleaned
  transceiver_data <- na.omit(transceiver_data)
  transceiver_data <- transceiver_data[order(transceiver_data$Time),]
  n<-nrow(transceiver_data)
  keepers <- rep(F, n)
  if (time=="hour"){
    spw <- 1800
  } else if (time=="day"){
    spw <- 43200
  } else if (time=="week"){
    spw <-302400
  }
  names(transceiver_data) <- c("Time", "Receiver", "Transmitter", "Region", "Station","Lat","Lon")
  for (i in 1:(n-1)){
    second_detect <- F
    j<-1
    while (second_detect==F & transceiver_data$Time[i+j]<=(transceiver_data$Time[i]+spw)){
      if (transceiver_data$Transmitter[i]==transceiver_data$Transmitter[i+j] & transceiver_data$Region[i]==transceiver_data$Region[i+j]){
        second_detect <- T
        break
      }
      j<-j+1
      if(i+j > n){
        break
      }
    }
    k<-1
    if (i-k>0 & second_detect==F){
      while (second_detect==F & transceiver_data$Time[i-k]>=(transceiver_data$Time[i]-spw)){
        
        if (transceiver_data$Transmitter[i]==transceiver_data$Transmitter[i-k] & transceiver_data$Region[i]==transceiver_data$Region[i-k]){
          second_detect <-T
          break
        }
        k<-k+1
        if (i-k < 1){
          break
        }
      }
    }
    keepers[i] <- second_detect
    if((i%%5000) == 0){
      print(round(i/n, 2))
    }
  }
  m <- sum(keepers)-n
  print(paste(m, "fish were detected only one time and moved from the returned data.frame", sep=" "))
  return(transceiver_data[keepers,])
}

# -------------------------------------------------------------------------
# Function to construct contingency table of the fish detected in a region by sex/condition
# May want to modify this so that there is just a "good" and "poor" condition
get.contingency.table <- function(transceiver_data_filtered, tagging_data_cleaned, region="Gravina", year=2017, sex=T, condition=F){
  detections <- transceiver_data_filtered[(transceiver_data_filtered$Region==region & get.year(transceiver_data_filtered$Time)==year), ]
  fish_detected <- levels(detections$Transmitter)
  if (sex == T & condition == F){
    n_male <- 0
    n_female <- 0
    n_unknown <- 0
    for (fish in fish_detected){
      fish_sex <- tagging_data_cleaned$Sex[tagging_data_cleaned$Transmitter == fish]
      if (length(fish_sex != 0)){
        if (fish_sex == "M"){
          n_male <- n_male + 1
        } else if (fish_sex =="F"){
          n_female <- n_female <- n_female + 1
        } else if (fish_sex == "UNK"){
          n_unknown <- n_unknown + 1
        }
      }
    }
    cont_table <- c(n_male, n_female, n_unknown)
    names(cont_table) <- c("Male", "Female", "Unknown")
    return(cont_table)
  }else if(sex == F & condition==T){
    tagging_data_cleaned <- tagging_data_cleaned[order(tagging_data_cleaned$Condition),]
    l_break <- tagging_data_cleaned$Condition[floor(nrow(tagging_data_cleaned)/3)]
    u_break <- tagging_data_cleaned$Condition[nrow(tagging_data_cleaned)-ceiling(nrow(tagging_data_cleaned)/3)]
    n_bad <- 0
    n_ok <- 0
    n_good <- 0
    for (fish in fish_detected){
      fish_condition <- tagging_data_cleaned$Condition[tagging_data_cleaned$Transmitter == fish]
      if (length(fish_condition != 0)){
        if (fish_condition <= l_break){
          n_bad <- n_bad + 1 
        }else if (fish_condition > l_break & fish_condition < u_break){
          n_ok <- n_ok + 1
        }else if (fish_condition >= u_break){
          n_good <- n_good + 1
        }
      }
    }
    cont_table <- c(n_bad, n_ok, n_good)
    names(cont_table) <- c("Bad", "OK", "Good")
    return(cont_table)
  }else if (sex == T & condition == T){
    tagging_data_cleaned <- tagging_data_cleaned[order(tagging_data_cleaned$Condition),]
    l_break <- tagging_data_cleaned$Condition[floor(nrow(tagging_data_cleaned)/3)]
    u_break <- tagging_data_cleaned$Condition[nrow(tagging_data_cleaned)-ceiling(nrow(tagging_data_cleaned)/3)]
    n_male_bad <- 0
    n_male_ok <- 0
    n_male_good <- 0
    n_female_bad <- 0
    n_female_ok <- 0
    n_female_good <- 0
    n_unknown_bad <- 0
    n_unknown_ok <- 0
    n_unknown_good <- 0
    for (fish in fish_detected){
      fish_sex <- tagging_data_cleaned$Sex[tagging_data_cleaned$Transmitter == fish]
      fish_condition <- tagging_data_cleaned$Condition[tagging_data_cleaned$Transmitter == fish]
      if (length(fish_sex != 0)){
        if (fish_condition <= l_break){
          if (fish_sex == "M"){
            n_male_bad <- n_male_bad + 1
          }else if (fish_sex == "F"){
            n_female_bad <- n_female_bad + 1
          }else if (fish_sex == "UNK"){
            n_unknown_bad <- n_unknown_bad + 1
          }
        }else if (fish_condition > l_break & fish_condition < u_break){
          if (fish_sex == "M"){
            n_male_ok <- n_male_ok + 1
          }else if (fish_sex == "F"){
            n_female_ok <- n_female_ok + 1
          }else if (fish_sex == "UNK"){
            n_unknown_ok <- n_unknown_ok + 1
          }
        }else if (fish_condition >= u_break){
          if (fish_sex == "M"){
            n_male_good <- n_male_good + 1
          }else if (fish_sex == "F"){
            n_female_good <- n_female_good + 1
          }else if (fish_sex == "UNK"){
            n_unknown_good <- n_unknown_good + 1
          }
        }
      }
    }
  }
  cont_table <- cbind(c(n_male_bad, n_male_ok, n_male_good), c(n_female_bad, n_female_ok, n_female_good), c(n_unknown_bad, n_unknown_ok, n_unknown_good))
  row.names(cont_table) <- c("Bad", "OK", "Good")
  colnames(cont_table) <- c("Male", "Female", "Unknown")
  return(cont_table)
}

# -------------------------------------------------------------------------
# Isolate receiver coordinate data
# Looks good
isolate.receiver.data <- function(transceiver_data_filtered){
  transceiver_data <- transceiver_data_filtered 
  library(dplyr)
  receiver_data <- data.frame(Receiver=transceiver_data$Receiver, Station=transceiver_data$Station, Region=transceiver_data$Region, Lat=transceiver_data$Lat, Lon=transceiver_data$Lon) %>% distinct()
  return(receiver_data)
}

# -------------------------------------------------------------------------
# Adds side information to the main df, removes duplicates so that there is a maximum of one detection for each time, and removes information that is no longer needed such as receiver info
# Looks good
add.side <- function(transceiver_data_filtered, receiver_data){
  library(dplyr)
  n<- nrow(transceiver_data_filtered)
  side <- rep(NA, n)
  for (i in 1:n){
    detection <- transceiver_data_filtered[i,]
    side[i] <- receiver_data$Side[receiver_data$Receiver==detection$Receiver & receiver_data$Station==detection$Station][1]
    if(i%%5000 == 0){
      print(round(i/n, 2))
    }
  }
  transceiver_data_side <- cbind(transceiver_data_filtered, side)
  names(transceiver_data_side)[8] <- "Side"
  transceiver_data_side <- transceiver_data_side[, -c(2,5,6,7)]
  transceiver_data_side$Side <- as.character(transceiver_data_side$Side)
  transceiver_data_side <- distinct(transceiver_data_side)
  n <- nrow(transceiver_data_side)
  side <- rep(NA, n)
  for (i in 1:n){
    detections <- transceiver_data_side[transceiver_data_side$Time == transceiver_data_side$Time[i] & transceiver_data_side$Transmitter == transceiver_data_side$Transmitter[i], ]
    detection_sides <- detections$Side
    if (length(unique(detection_sides)) == 1){
      side[i] <- detection_sides[1]
    }else{
      side[i] <- "both"
    }
    if(i%%5000 == 0){
      print(round(i/n, 2))
    }
  }
  transceiver_data_side$Side <- side
  transceiver_data_side$Side <- as.factor(transceiver_data_side$Side)
  return(transceiver_data_side)
}

# -------------------------------------------------------------------------
# Function to determine the observed data associated with each detection following the encoding below:
# Looks good
# 1 -- No detection
# 2 -- Gravina, RedGravina, Hawkins, or NoMontague
# 3 -- Entrance Array

add.observation.encoding <- function(transceiver_data_side){
  n <- nrow(transceiver_data_side)
  obs.enc <- rep(NA, n)
  for (i in 1:n){
    detection <- transceiver_data_side[i,]
    if (detection$Region == "Gravina" || detection$Region == "RedGravina" || detection$Region == "Hawkins" || detection$Region == "NoMontague"){
      obs.enc[i] <- 2
    }else{
      obs.enc[i] <- 3
    }
    if(i%%5000 == 0){
      print(round(i/n, 2))
    }
  }
  obs_data <- cbind(transceiver_data_side[,c(1,2,4)], obs.enc)
  names(obs_data)[4] <- "Obs" 
  return(obs_data)
}


# -------------------------------------------------------------------------
# Function to return the time the first fish was released
get.start.time <- function(tagging_data_cleaned){
  return(min(tagging_data_cleaned$ReleaseTime))
}

# -------------------------------------------------------------------------
# Compute the detection or "capture" history for each individual
# Looks good
get.detecton.history.list <- function(transceiver_data_encoded, start_time, end_time){
  get.day <- function(time, start_time){
    day <- rep(NA, length(time))
    for (i in 1:length(time)){
      day[i] <- as.numeric(ceiling(difftime(time[i], start_time, units="days")))
      if (day[i] == 0){
        day[i] <- 1
      }
    }
    return(day)
  }
  num_days <- get.day(end_time, start_time)
  days <- get.day(transceiver_data_encoded$Time, start_time)
  detection_histories <- list()
  for (j in 1:length(levels(transceiver_data_encoded$Transmitter))){
    fish <- levels(transceiver_data_encoded$Transmitter)[j]
    obs <- rep(NA, num_days)
    direction <- rep(NA, num_days)
    for (day in 1:num_days){
      detections <- transceiver_data_encoded[transceiver_data_encoded$Transmitter==fish & days == day, ]
      if (nrow(detections)==0){
        obs[day] <- 1
      } else if (length(unique(detections$Obs))==1){
        obs[day] <- detections$Obs[1]
        if (length(unique(detections$Side)) != 1){
          first_side <- detections$Side[1]
          last_side <- detections$Side[nrow(detections)]
          if (first_side == "in" & last_side == "out"){
            direction[day] <- "io"
          } else if (first_side=="out" & last_side == "in"){
            direction[day] <- "oi"
          }
        }
      } else{
        obs[day] <- detections$Obs[1]
        print(paste("Fish", levels(transceiver_data_encoded$Transmitter)[j], "detected in different regions on day", day, sep=" "))
        print("using the first region where the fish was detected")
      }
    }
    detection_histories[[j]] <- data.frame(obs, direction)
    if(j%%10 == 0){
      print(round(j/length(levels(transceiver_data_encoded$Transmitter)), 2))
    }
  }
  names(detection_histories) <- levels(transceiver_data_encoded$Transmitter)
  return(detection_histories)
}


# -------------------------------------------------------------------------
# Function to extract data to be used in Jags model
# Needs to be debugged
get.y <- function(detection_history_list){
  y <- matrix(NA, nrow=length(detection_history_list), ncol=nrow(detection_history_list[[1]]))
  row.names(y) <- names(detection_history_list)
  for (i in 1:length(detection_history_list)){
    y[i,] <- detection_history_list[[i]][,1]
  }
  return(y)
}

# -------------------------------------------------------------------------
# Function to tell us how many days are in each season
get.days.per.season <- function(date_vector){
  new_date_vector <- as.POSIXct(date_vector)
  days <- rep(NA, (length(date_vector)-1))
  for (i in 1:(length(date_vector)-1)){
    days[i] <- as.numeric(round(difftime(date_vector[[i+1]], date_vector[[i]], units="days")))
  }
  return(days)
}

# -------------------------------------------------------------------------
# Function to extract side counts to determine where the informative priors are centered
# There are two versions here depending upon what we want to do
get.side.counts <- function(days_per_season, detection_history_list, by, tagging_data_cleaned){
  if (by =="sex"){
    index <- 6
  }else if (by=="cohort"){
    index <- 2
  }else if (by=="condition"){
    index <- 5
  }
  io_mat <- matrix(0, nrow=length(days_per_season), ncol=length(levels(tagging_data_cleaned[,index])))
  oi_mat <- matrix(0, nrow=length(days_per_season), ncol=length(levels(tagging_data_cleaned[,index])))
  for(k in 1:length(levels(tagging_data_cleaned[,index]))){
    fish_ids <- tagging_data_cleaned$Transmitter[tagging_data_cleaned[,index]==levels(tagging_data_cleaned[,index])[k]]
    for (i in 1:length(detection_history_list)){
      if (is.element(names(detection_history_list)[i], tagging_data_cleaned$Transmitter)){
        if (is.element(names(detection_history_list)[i], fish_ids)){
          lb <- 1
          ub <- days_per_season[1]
          for (j in 1:length(days_per_season)){
            io_mat[j,k] <- io_mat[j,k] + sum(na.omit(detection_history_list[[i]][lb:ub,2]=="io"))
            oi_mat[j,k] <- oi_mat[j,k] + sum(na.omit(detection_history_list[[i]][lb:ub,2]=="oi"))
            lb <- lb + days_per_season[j]
            if (j != length(days_per_season)){
              ub <- ub + days_per_season[j+1]
            }
          }
        }
      }
    }
  }
  return(list("io"=io_mat,"oi"=oi_mat))
}    

get.side.counts <- function(days_per_season, detection_history_list, by, tagging_data_cleaned){
  side_counts <- matrix(0, nrow = 2, ncol=length(days_per_season))
  rownames(side_counts) <- c("io", "oi")
  for (i in 1:length(detection_history_list)){
    lb <- 1
    ub <- days_per_season[1]
    for (j in 1:length(days_per_season)){
      side_counts[1,j] <- side_counts[1,j] + sum(na.omit(detection_history_list[[i]][lb:ub,2]=="io"))
      side_counts[2,j] <- side_counts[2,j] + sum(na.omit(detection_history_list[[i]][lb:ub,2]=="oi"))
      lb <- lb + days_per_season[j]
      if (j != length(days_per_season)){
        ub <- ub + days_per_season[j+1]
      }
    }
  }
  return(side_counts)
}



# -------------------------------------------------------------------------
# function to add the detection history of the fish that was never heard from again
add.fish.to.y <- function(id, y){
  dh <- rep(1, ncol(y))
  new_y <- rbind(y, dh)
  rownames(new_y)[nrow(new_y)]<-id
  return(new_y)
}

# -------------------------------------------------------------------------
# Since I don't have the full set of tagging data, extract the 2017 fish
y.2017 <- function(y, tagging_data_cleaned){
  y_2017 <- matrix(NA, nrow=length(tagging_data_cleaned$Transmitter), ncol=ncol(y))
  for (i in 1:nrow(tagging_data_cleaned)){
    y_2017[i,] <- y[rownames(y)==tagging_data_cleaned$Transmitter[i],]
  }
  rownames(y_2017) <- tagging_data_cleaned$Transmitter
  return(y_2017)
}

# -------------------------------------------------------------------------
# Functions to extract constraint information for Jags model
# 1 -- Female
# 2 -- Male
# 3 -- Unknown
get.sex <- function(y, tagging_data_cleaned){
  sex <- rep(NA, nrow(y))
  for (i in 1:length(rownames(y))){
    fish <- rownames(y)[i]
    sex[i] <- as.character(tagging_data_cleaned$Sex[tagging_data_cleaned$Transmitter==fish])
  }
  return(as.numeric(as.factor(sex)))
}

get.cohort <- function(y, tagging_data_cleaned){
  cohort <- rep(NA, nrow(y))
  for (i in 1:length(rownames(y))){
    fish <- rownames(y)[i]
    cohort[i] <- tagging_data_cleaned$Cohort[tagging_data_cleaned$Transmitter==fish]
  }
  return(cohort)
}

# 1 -- good
# 2 -- poor
get.condition <- function(y, tagging_data_cleaned){
  condition <- rep(NA, nrow(y))
  for (i in 1:length(rownames(y))){
    fish <- rownames(y)[i]
    condition[i] <- tagging_data_cleaned$Condition[tagging_data_cleaned$Transmitter==fish]
  }
  return(as.numeric(as.factor(condition)))
}

# -------------------------------------------------------------------------
get.tagging.time <- function(tagging_data_cleaned){
  tt <- rep(NA, nrow(tagging_data_cleaned)) 
  first_tt <- min(tagging_data_cleaned$ReleaseTime)
  for(i in 1:nrow(tagging_data_cleaned)){
    tt[i] <- as.numeric(round(difftime(tagging_data_cleaned$ReleaseTime[i], first_tt, units="days")))
  }
  return(tt)
}


# -------------------------------------------------------------------------
# function to find to season cooresponding to each day
get.season<- function(dps){
  seasons <- c()
  for (i in 1:length(dps)){
    seasons <- c(seasons, rep(i,dps[i])) 
  }
  return(seasons)
}





# -------------------------------------------------------------------------
# Continuing to move data into Jags Model








































# -------------------------------------------------------------------------
# -------------------------------------------------------------------------
# Below is a bunch of Etc. code to be used in diagnostics and/or deleted
# -------------------------------------------------------------------------
# -------------------------------------------------------------------------




# -------------------------------------------------------------------------
# A few functions to extract the year, month, and day from a POSIXct date
get.year <- function(POSIXt_time){
  return(as.numeric(format(POSIXt_time, format="%Y")))
}
get.month <- function(POSIXt_time){
  return(as.numeric(format(POSIXt_time, format="%m")))
}
get.day <- function(POSIXt_time){
  return(as.numeric(format(POSIXt_time, format="%d")))
}

# -------------------------------------------------------------------------
# Function that returns passage times at a given receiver, station, or region and a histogram of the return times. Additional arguments allow for the specification of the calendar year, transmitter id, and histogram breaks points

plot.detection.times(transceiver_data_filtered, "Bainbridge")

plot.detection.times <- function(transceiver_data_filtered, 
                                 year="unspecified", 
                                 receiver="unspecified", 
                                 station="unspecified", 
                                 region="unspecified", 
                                 transmitter="unspecified", 
                                 breaks="days"){
  
  plot_data <- transceiver_data_filtered
  if (year!="unspecified"){
    plot_data <- plot_data[get.year(plot_data$Time)==year, ]
  }
  if (receiver!="unspecified"){
    plot_data <- plot_data[plot_data$Receiver==receiver, ]
  }
  if (station!="unspecified"){
    plot_data <- plot_data[plot_data$Station==station, ]
  }
  if(region!="unspecified"){
    plot_data <- plot_data[plot_data$Region==region, ]
  }
  if(transmitter!="unspecified"){
    plot_data <- plot_data[plot_data$Transmitter==transmitter, ]
  }
  if (nrow(plot_data) == 0){
    print("there were no detections")
  }else{
    detect_times <- plot_data$Time
    hist(detect_times, breaks)
    return(detect_times)
  }
}

# -------------------------------------------------------------------------


# -------------------------------------------------------------------------














# A functions to return the region where a receiver or station is located
get.region <- function(data, station="unspecified", receiver="unspecified"){
  if (station != "unspecified"){
    return(data$Region[data$Station==station][1])
  }else if (receiver != unspecified){
    return(data$Region[data$Receiver==receiver][1])
  }
}




# Function to return the number of detections of a given fish. Additional argument is added to allow for year specification
get.num.detect <- function(data, transmitter, year="unspecified"){
  if (year =="unspecified"){
    return(sum(data$Transmitter==transmitter))
  }else{
    return(sum(data$Transmitter==transmitter) & data$Year==year)
  }
  
}


# Function returning a data.frame of times and stations where a given fish was located
get.detection.stations <- function(transmitter){
  return(data.frame(Time = data$Time[data$Transmitter==transmitter], Station = data$Station[data$Transmitter==transmitter]))
}


# Function returning a data.frame of times and regions where a given fish was located
get.detection.regions <- function(transmitter){
  return(data.frame(Time = data$Time[data$Transmitter==transmitter], Region = data$Region[data$Transmitter==transmitter]))
}

  


















