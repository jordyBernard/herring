jags_model_1 <- "model{
# -------- Priors --------
p_1 ~ dbeta(1,1) # non-informative beta prior for the detection prob for the pws arrays
p_2 ~ dbeta(1,1) # non-informative beta prior for the detection prob for the entrance arrays
for (s in 1:n_seasons){ # iterate over seasons
  for (x in 1:n_x_vals){ # iterate over each constraint value
    psi[s,x] ~ dbeta(1,1)
    phi_12[s,x] ~ dbeta(1,1)
    phi_21[s,x] ~ dbeta(1,1)
    phi_23[s,x] ~ dbeta(io[s,x], oi[s,x])
    phi_32[s,x] ~ dbeta(oi[s,x], io[s,x])
  }
}

# -------- Transition Matrix --------
for(s in 1:n_seasons){
  for(x in 1:n_x_vals){
    tr[1,1,s,x] <- 1  # dead to dead
    tr[2,1,s,x] <- 0  # dead to pws array
    tr[3,1,s,x] <- 0  # dead to pws
    tr[4,1,s,x] <- 0  # dead to entrance array
    tr[5,1,s,x] <- 0  # dead to goa
    tr[1,2,s,x] <- psi[s,x] # pws array to dead
    tr[2,2,s,x] <- 1-psi[s,x]-phi_12[s,x] # pws array to pws array
    tr[3,2,s,x] <- phi_12[s,x] # pws array to pws array
    tr[4,2,s,x] <- 0  # pws array to entrance array
    tr[5,2,s,x] <- 0  # pws array to goa
    tr[1,3,s,x] <- psi[s,x] # pws to dead
    tr[2,3,s,x] <- phi_21[s,x] # pws to pws array
    tr[3,3,s,x] <- 1-psi[s,x]-phi_21[s,x]-phi_23[s,x] # pws to pws
    tr[4,3,s,x] <- phi_23[s,x] # pws to entrance array
    tr[5,3,s,x] <- 0  # pws undetected to goa
    tr[1,4,s,x] <- psi[s,x] # entrance array to dead
    tr[2,4,s,x] <- 0  # entrance array to pws array
    tr[3,4,s,x] <- phi_32[s,x]  # entrance array to pws
    tr[4,4,s,x] <- 1-psi[s,x]-phi_32[s,x]-phi_23[s,x]  # entrance array to entrance array
    tr[5,4,s,x] <- phi_23[s,x]  # entrance array to goa
    tr[1,5,s,x] <- psi[s,x] # goa to dead
    tr[2,5,s,x] <- 0  # goa to pws array
    tr[3,5,s,x] <- 0  # goa to pws
    tr[4,5,s,x] <- phi_32[s,x]  # goa to entrance array
    tr[5,5,s,x] <- 1-psi[s,x]-phi_32[s,x]  # goa to goa
  }
}


# -------- Emission Matrix --------
em[1,1] <- 1  # dead and no detection
em[2,1] <- 0  # dead and pws detection
em[3,1] <- 0  # dead and entrance detection
em[1,2] <- 1-p_1  # pws array and no detection
em[2,2] <- p_1  # pws array and pws detection
em[3,2] <- 0  # pws array and entrance detection
em[1,3] <- 1  # pws and no detection
em[2,3] <- 0  # pws and pws detection
em[3,3] <- 0  # pws and entrance detection
em[1,4] <- 1-p_2  # entrance array and no detection
em[2,4] <- 0  # entrance array and pws detection
em[3,4] <- p_2  # entrance array and entrance detection
em[1,5] <- 1  # goa and no detection
em[2,5] <- 0  # goa and pws detection
em[3,5] <- 0  # goa and entrance detection


# -------- Likelihood --------
# Latent Process
for (i in 1:M){ # iterate over each fish
  z[i,t_0[i]] ~ dcat(tr[,2, season[t_0[i]], x_data[i]]) # first state is Gravina
  for (t in t_0[i]:min(total_days-1, t_0[i]+tl[i]-1)){ # iterate over times when tag is alive
    z[i,t+1] ~ dcat(tr[,z[i,t], season[t+1], x_data[i]]) # z_{t+1}|z_t
  }
}
# Conditional Likelihood
for(i in 1:M){ # iterate over each fish
  for(t in t_0[i]:min(total_days,t_0[i]+tl[i])){ # iterate over times when tag is alive
     y_data[i,t] ~ dcat(em[,z[i,t]]) # y_t|z_t
  }
}
  
  
# -------- Reparameterize --------
# diagonals of transition matrix
for (s in 1:n_seasons){
  for(x in 1:n_x_vals){
    phi_11[s,x] <- 1-psi[s,x]-phi_12[s,x]
    phi_22[s,x] <- 1-psi[s,x]-phi_21[s,x]-phi_23[s,x]
    phi_33[s,x] <- 1-psi[s,x]-phi_32[s,x]-phi_23[s,x]
    phi_44[s,x] <- 1-psi[s,x]-phi_32[s,x]
  }
}

# constraint coefficients
for (s in 1:n_seasons){
  for(x in 1:n_x_vals){
    mu_12[s,x] <- ilogit(phi_12[s,x])
    mu_21[s,x] <- ilogit(phi_21[s,x])
    mu_23[s,x] <- ilogit(phi_23[s,x])
    mu_32[s,x] <- ilogit(phi_32[s,x])
  }
}
for (x in 1:n_x_vals){
  beta_12[1,x] <- mu_12[1,x]
  beta_21[1,x] <- mu_21[1,x]
  beta_32[1,x] <- mu_32[1,x]
  beta_23[1,x] <- mu_23[1,x]
  for (s in 2:n_seasons){
    beta_12[s,x] <- mu_12[s,x]-mu_12[1,x]
    beta_21[s,x] <- mu_21[s,x]-mu_21[1,x]
    beta_32[s,x] <- mu_32[s,x]-mu_32[1,x]
    beta_23[s,x] <- mu_23[s,x]-mu_23[1,x]
  }
}



}"

con_1 <- "C:/Users/19708/Desktop/Herring/Modeling/R/Jags/jags-model-1.bugs"
writeLines(jags_model_1, con=con_1)
