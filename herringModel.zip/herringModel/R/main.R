################################################################################################################################################
# Main module
#############

# Read in PWS shapefile and convert to SpatialPolygonsDataFrame
{
  library(rgdal)
  library(raster)
  library(rgeos)
  download.file("http://www.naturalearthdata.com/http//www.naturalearthdata.com/download/10m/physical/ne_10m_coastline.zip", destfile="coastlines.zip")
  unzip(zipfile="coastlines.zip", exdir="ne-coastlines-10m")
  coastlines<-readOGR("ne-coastlines-10m/ne_10m_coastline.shp")
  pwsExtent<-extent(-148.829400, -145.376399, 59.522309, 61.399354)
  pwsCoast<-crop(coastlines, pwsExtent)
  landCoords <- rbind(c(-148.829400, 59.94281),c(-148.829400, 61.39354),c(-145.376399, 61.39354),c(-145.376399, 60.36151), coordinates(pwsCoast)[[14]][[1]])
  waterCoords <- rbind(c(-148.829400,59.95100),c(-148.829400,59.522309),c(-145.376399, 59.522309),c(-145.376399, 60.36151), coordinates(pwsCoast)[[14]][[1]])
  islandCoords <- coordinates(pwsCoast)[-14]
  landPolys <- Polygons(list(Polygon(landCoords)), ID="land")
  waterPolys <- Polygons(list(Polygon(waterCoords)), ID="water")
  islandPoly <- lapply(islandCoords, Polygon)
  islandPolys <- list()
  index <- 1:length(islandPoly)
  for(i in 1:length(islandPoly)){
    islandPolys[[i]] <- Polygons(islandPoly, ID=paste("island", index[i], sep=" "))
  }
  SPs <- SpatialPolygons(c(landPolys, waterPolys, islandPolys))
  names<-c("land","water", paste("island", index, sep=" "))
  SPDF = SpatialPolygonsDataFrame(SPs, data.frame(N = names, row.names = names))
}

# Basic Plot
plot(SPDF, asp=2, col=c("green", "blue", rep("green", length(islandPoly))))

# Read in transceiver data
library(readxl)
transceiver_data_raw <- read_excel("C:/Users/19708/Desktop/Herring/Modeling/Data/transceiver-data.xlsx", sheet = "herring 2017 and beyond jun 201")

# Clean transceiver data
transceiver_data_cleaned <- clean.transceiver.data(transceiver_data_raw)

# To remove isolated (single) detections and remove dead transmitters
transceiver_data_filtered <- filter.single.detections(transceiver_data_cleaned)

# Read in tagging data
tagging_data_raw <- read_excel("C:/Users/19708/Desktop/Herring/Modeling/Data/tagging-data.xlsx", sheet = "HerringTaggingLog_2017")

# Clean tagging data
tagging_data_cleaned <- clean.tagging.data(tagging_data_raw)
tagging_data_cleaned <- bin.condition(tagging_data_cleaned)

# For each receiver, determine if the receiver is located at an entrance array and if it lies on the inside or outside of the entrance array. 
# Summarize relevant receiver information inside of receiver_data.
# Note: some of the plots look a little funny because of a low resolution shapefile 
{
  # Isolate relavant receiver data
  receiver_data <- isolate.receiver.data(transceiver_data_filtered)

  # For the Hinchinbrook array
  hinch_array <- receiver_data[receiver_data$Region=="Hinchinbrook",]
  # plot(SPDF, asp=2, col=c("green", "blue", rep("green", length(islandPoly))), xlim=c(-147,-146.5), ylim=c(60.35,60.36))
  # points(hinch_array$Lon, hinch_array$Lat, col="orange", pch=19, cex=1)
  # points(hinch_array$Lon[1], hinch_array$Lat[1], col="black", pch=19, cex=1.5) # out 
  # points(hinch_array$Lon[2], hinch_array$Lat[2], col="black", pch=19, cex=1.5) # in 
  # points(hinch_array$Lon[3], hinch_array$Lat[3], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[4], hinch_array$Lat[4], col="black", pch=19, cex=1.5) # out
  # points(hinch_array$Lon[5], hinch_array$Lat[5], col="black", pch=19, cex=1.5) # out
  # points(hinch_array$Lon[6], hinch_array$Lat[6], col="black", pch=19, cex=1.5) # out
  # points(hinch_array$Lon[7], hinch_array$Lat[7], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[8], hinch_array$Lat[8], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[9], hinch_array$Lat[9], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[10], hinch_array$Lat[10], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[11], hinch_array$Lat[11], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[12], hinch_array$Lat[12], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[13], hinch_array$Lat[13], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[14], hinch_array$Lat[14], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[15], hinch_array$Lat[15], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[16], hinch_array$Lat[16], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[17], hinch_array$Lat[17], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[18], hinch_array$Lat[18], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[19], hinch_array$Lat[19], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[20], hinch_array$Lat[20], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[21], hinch_array$Lat[21], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[22], hinch_array$Lat[22], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[23], hinch_array$Lat[23], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[24], hinch_array$Lat[24], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[25], hinch_array$Lat[25], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[26], hinch_array$Lat[26], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[27], hinch_array$Lat[27], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[28], hinch_array$Lat[28], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[29], hinch_array$Lat[29], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[30], hinch_array$Lat[30], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[31], hinch_array$Lat[31], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[32], hinch_array$Lat[32], col="black", pch=19, cex=1.5) # in
  # points(hinch_array$Lon[33], hinch_array$Lat[33], col="black", pch=19, cex=1.5) # in
  hinch_array[,6]<-c("out", "in", "in", "out", "out", "out", rep("in", 27))
  names(hinch_array)[6]<-"Side"
  hinch_array <- hinch_array[,-c(4,5)]

  # For Montague 26
  mont_array <- receiver_data[receiver_data$Region=="Montague",]
  # plot(SPDF, asp=2, col=c("green", "blue", rep("green", length(islandPoly))), xlim=c(-147.9,-147.8), ylim=c(59.9,60))
  # points(mont_array$Lon, mont_array$Lat, col="orange", pch=19, cex=1)
  # points(mont_array$Lon[1], mont_array$Lat[1], col="black", pch=19, cex=1) # in
  # points(mont_array$Lon[2], mont_array$Lat[2], col="black", pch=19, cex=1) # out
  # points(mont_array$Lon[3], mont_array$Lat[3], col="black", pch=19, cex=1) # in
  # points(mont_array$Lon[4], mont_array$Lat[4], col="black", pch=19, cex=1) # out
  # points(mont_array$Lon[5], mont_array$Lat[5], col="black", pch=19, cex=1) # in
  # points(mont_array$Lon[6], mont_array$Lat[6], col="black", pch=19, cex=1) # in
  # points(mont_array$Lon[7], mont_array$Lat[7], col="black", pch=19, cex=1) # in
  # points(mont_array$Lon[8], mont_array$Lat[8], col="black", pch=19, cex=1) # in
  # points(mont_array$Lon[9], mont_array$Lat[9], col="black", pch=19, cex=1) # out
  # points(mont_array$Lon[10], mont_array$Lat[10], col="black", pch=19, cex=1) # out
  # points(mont_array$Lon[11], mont_array$Lat[11], col="black", pch=19, cex=1) # in
  # points(mont_array$Lon[12], mont_array$Lat[12], col="black", pch=19, cex=1) # out
  # points(mont_array$Lon[13], mont_array$Lat[13], col="black", pch=19, cex=1) # out
  # points(mont_array$Lon[14], mont_array$Lat[14], col="black", pch=19, cex=1) # in
  # points(mont_array$Lon[15], mont_array$Lat[15], col="black", pch=19, cex=1) # out
  # points(mont_array$Lon[16], mont_array$Lat[16], col="black", pch=19, cex=1) # in
  # points(mont_array$Lon[17], mont_array$Lat[17], col="black", pch=19, cex=1) # in
  # points(mont_array$Lon[18], mont_array$Lat[18], col="black", pch=19, cex=1) # out
  # points(mont_array$Lon[19], mont_array$Lat[19], col="black", pch=19, cex=1) # out
  # points(mont_array$Lon[20], mont_array$Lat[20], col="black", pch=19, cex=1) # in
  # points(mont_array$Lon[21], mont_array$Lat[21], col="black", pch=19, cex=1) # in
  # points(mont_array$Lon[22], mont_array$Lat[22], col="black", pch=19, cex=1) # out
  # points(mont_array$Lon[23], mont_array$Lat[23], col="black", pch=19, cex=1) # out
  # points(mont_array$Lon[24], mont_array$Lat[24], col="black", pch=19, cex=1) # out
  # points(mont_array$Lon[25], mont_array$Lat[25], col="black", pch=19, cex=1) # in
  # points(mont_array$Lon[26], mont_array$Lat[26], col="black", pch=19, cex=1) # out
  mont_array[,6]<-c("in","out","in","out","in","in","in","in","out","out","in","out","out","in","out","in","in","out","out","in","in","out","out","out","in","out")
  names(mont_array)[6]<-"Side"
  mont_array <- mont_array[,-c(4,5)]

  # For Elrington 8
  elring_array <- receiver_data[receiver_data$Region=="Elrington",]
  # plot(SPDF, asp=2, col=c("green", "blue", rep("green", length(islandPoly))), xlim=c(-148.15,-148.04), ylim=c(59.87,60.02))
  # points(elring_array$Lon, elring_array$Lat, col="orange", pch=19, cex=1)
  # points(elring_array$Lon[1], elring_array$Lat[1], col="black", pch=19, cex=1) # in
  # points(elring_array$Lon[2], elring_array$Lat[2], col="black", pch=19, cex=1) # in
  # points(elring_array$Lon[3], elring_array$Lat[3], col="black", pch=19, cex=1) # out
  # points(elring_array$Lon[4], elring_array$Lat[4], col="black", pch=19, cex=1) # out
  # points(elring_array$Lon[5], elring_array$Lat[5], col="black", pch=19, cex=1) # in
  # points(elring_array$Lon[6], elring_array$Lat[6], col="black", pch=19, cex=1) # out
  # points(elring_array$Lon[7], elring_array$Lat[7], col="black", pch=19, cex=1) # out
  # points(elring_array$Lon[8], elring_array$Lat[8], col="black", pch=19, cex=1) # in
  elring_array[,6]<-c("in","in","out","out","in","out","out","in")
  names(elring_array)[6]<-"Side"
  elring_array <- elring_array[,-c(4,5)]

  # For Prince of Wales 7
  pow_array <- receiver_data[receiver_data$Region=="Prince of Wales",]
  # plot(SPDF, asp=2, col=c("green", "blue", rep("green", length(islandPoly))), xlim=c(-148.181, -148.0692), ylim=c(59.87,60.07394))
  # points(pow_array$Lon, pow_array$Lat, col="orange", pch=19, cex=1)
  # points(pow_array$Lon[1], pow_array$Lat[1], col="black", pch=19, cex=1) # out
  # points(pow_array$Lon[2], pow_array$Lat[2], col="black", pch=19, cex=1) # in
  # points(pow_array$Lon[3], pow_array$Lat[3], col="black", pch=19, cex=1) # in
  # points(pow_array$Lon[4], pow_array$Lat[4], col="black", pch=19, cex=1) # out
  # points(pow_array$Lon[5], pow_array$Lat[5], col="black", pch=19, cex=1) # in
  # points(pow_array$Lon[6], pow_array$Lat[6], col="black", pch=19, cex=1) # out
  # points(pow_array$Lon[7], pow_array$Lat[7], col="black", pch=19, cex=1) # in
  pow_array[,6]<-c("out","in","in","out","in","out","in")
  names(pow_array)[6]<-"Side"
  pow_array <- pow_array[,-c(4,5)]

  # For LaTouche 6
  latouche_array <- receiver_data[receiver_data$Region=="LaTouche",]
  # plot(SPDF, asp=2, col=c("green", "blue", rep("green", length(islandPoly))), xlim=c(-148.0833, -147.9567), ylim=c(59.92625,60.01064 ))
  # points(latouche_array$Lon, latouche_array$Lat, col="orange", pch=19, cex=1)
  # points(latouche_array$Lon[1], latouche_array$Lat[1], col="black", pch=19, cex=1) # in
  # points(latouche_array$Lon[2], latouche_array$Lat[2], col="black", pch=19, cex=1) # in
  # points(latouche_array$Lon[3], latouche_array$Lat[3], col="black", pch=19, cex=1) # out
  # points(latouche_array$Lon[4], latouche_array$Lat[4], col="black", pch=19, cex=1) # out
  # points(latouche_array$Lon[5], latouche_array$Lat[5], col="black", pch=19, cex=1) # out
  # points(latouche_array$Lon[6], latouche_array$Lat[6], col="black", pch=19, cex=1) # out
  latouche_array[,6] <- c("in","in","out","out","out","out") 
  names(latouche_array)[6] <- "Side"
  latouche_array <- latouche_array[,-c(4,5)]

  # For Bainbridge 2
  bain_array <- receiver_data[receiver_data$Region=="Bainbridge",]
  # plot(SPDF, asp=2, col=c("green", "blue", rep("green", length(islandPoly))), xlim=c(-148.2942, -148.1817), ylim=c(60.06690,60.14426 ))
  # points(bain_array$Lon, bain_array$Lat, col="orange", pch=19, cex=1)
  # points(bain_array$Lon[1], bain_array$Lat[1], col="black", pch=19, cex=1) # out
  # points(bain_array$Lon[2], bain_array$Lat[2], col="black", pch=19, cex=1) # in
  bain_array[,6] <- c("out", "in")
  names(bain_array)[6]<-"Side"
  bain_array <- bain_array[,-c(4,5)]

  # For Gravina
  grav_array <- receiver_data[receiver_data$Region=="Gravina",]
  grav_array <- grav_array[,-c(4,5)]
  grav_array[,4] <- NA
  names(grav_array)[4] <- "Side"

  # For RedGravina
  red_grav_array <- receiver_data[receiver_data$Region=="RedGravina",]
  red_grav_array <- red_grav_array[,-c(4,5)]
  red_grav_array[,4] <- NA
  names(red_grav_array)[4] <- "Side"
  
  # For Hawkins
  hawk_array <- receiver_data[receiver_data$Region=="Hawkins",]
  hawk_array <- hawk_array[,-c(4,5)]
  hawk_array[,4] <- NA
  names(hawk_array)[4] <- "Side"

  # For NoMontague
  noMont_array <- receiver_data[receiver_data$Region=="NoMontague",]
  noMont_array <- noMont_array[,-c(4,5)]
  noMont_array[,4] <- NA
  names(noMont_array)[4] <- "Side"

  # Summarize all of the array info in a data frame
  receiver_data <- rbind(grav_array, red_grav_array, hawk_array, noMont_array, hinch_array, mont_array, elring_array, pow_array, latouche_array, bain_array)
}

# Add this information to the main data.frame
transceiver_data_side <- add.side(transceiver_data_filtered, receiver_data)

# Determine the state associated with each detection
transceiver_data_encoded <- add.observation.encoding(transceiver_data_side)

# When did the experiment start/end
start_time <- get.start.time(tagging_data_cleaned)
end_time <- max(transceiver_data_filtered$Time) # This is just the last date of detection -- fill with the date data was uploaded in 2019 when we get it from Mary

# Compute detection histories for each individual
detection_history_list <- get.detecton.history.list(transceiver_data_encoded, start_time, end_time)

# So that I don't need to re-run stuff
save(detection_history_list, file="C:/Users/19708/Desktop/detection-history-list.RData")
load("C:/Users/19708/Desktop/detection-history-list.RData")




# -------------------------------------------------------------------------
# Clean up what's below


# Get observed data
y<-get.y(detection_history_list)
y <- add.fish.to.y("A69-1601-51550", y)
y_2017 <- y.2017(y, tagging_data_cleaned)

date_vector <- c("2017-04-09","2017-08-31", "2018-02-28", "2018-08-31", "2019-02-28" , "2019-06-01")
dps <- get.days.per.season(date_vector)



# For Jags
y_data <- y.2017(y, tagging_data_cleaned)
x_data <- get.sex(y_2017, tagging_data_cleaned)
t_0<-get.tagging.time(tagging_data_cleaned)+1
io <- get.side.counts(dps, detection_history_list, by="sex", tagging_data_cleaned)$io+1
oi <- get.side.counts(dps, detection_history_list, by="sex", tagging_data_cleaned)$oi+1
M <- nrow(y_data)
n_seasons <- 5
n_x_vals <- 3
total_days <- sum(dps)
tag_life <- tagging_data_cleaned$TagLife
season <- get.season(dps)
library(rjags)
jags.model(con_1,
          data = list(y_data=y_data, x_data=x_data,t_0=t_0, io=io, oi=oi,M=M,n_seasons=n_seasons,n_x_vals=n_x_vals,total_days=total_days, season=season),
          n.chains = 1,
          n.adapt = 5)

